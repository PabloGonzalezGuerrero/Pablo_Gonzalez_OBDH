/*
 * emu_tc_programming.cpp
 *
 *  Created on: Oct 26, 2024
 *      Author: Oscar Rodriguez Polo
 */

/****************************************************************************
 *
 *   This program is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License
 *   as published by the Free Software Foundation; either version 2
 *   of the License, or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,USA.
 *
 *
 ****************************************************************************/

#include <public/emu_hw_timecode_drv_v1.h>
#include <public/emu_sc_channel_drv_v1.h>
#include <public/emu_gss_v1.h>

#define OBT_START_FT_ST19 (OBT_AFTER_POWER_ON + 0)

#define FT_UAH_ASW_Event_Action_0110


#ifdef FT_UAH_ASW_Event_Action_0110

#define FT_0110_TIME_step0 (OBT_START_FT_ST19 + 3)
#define FT_0110_TIME_step1 (OBT_START_FT_ST19 + 4)
#define FT_0110_TIME_step2 (OBT_START_FT_ST19 + 9)
#define FT_0110_TIME_step3 (OBT_START_FT_ST19 + 20)
#define FT_0110_TIME_step4 (OBT_START_FT_ST19 + 30)
#define FT_0110_TIME_step5 (OBT_START_FT_ST19 + 40)

EmuGSS_TCProgram20_3_uint8 prog_FT_0110_step_0A(FT_0110_TIME_step0,
		"FT_UAH_ASW_ICU_Monitoring_0110 step 0, Set PID 15 to 5",15,5);

EmuGSS_TCProgram12_5_Limit_UINT8 prog_FT_0110_step_1(FT_0110_TIME_step1,
		"FT_UAH_ASW_ICU_Monitoring_0110 step 0B, Config PMODID 0 for monitoring PID 15",
		0, 15, 1, 2, 1, 0x4001, 20, 0x4002);

EmuGSS_TCProgram19_1_Action_2_1 prog_FT_0110_step_2(FT_0110_TIME_step2,
					"FT_UAH_ASW_Event_Action_0110 step 1, 0x4002 Action is Device  Off",
					0x4002, DeviceCommandOff);

//TODO Complete Test in order to force the DeviceCommandOff execution
//as recovery action After step 5.

// PASO 3: Habilitar la definición de Evento-Acción para el evento 0x4002
// Sin este paso, aunque la acción esté definida, el sistema la ignorará.
EmuGSS_TCProgram19_4 prog_FT_0110_step_3(FT_0110_TIME_step3,
        "FT_UAH_ASW_Event_Action_0110 step 3, Enable Event-Action for 0x4002",
        0x4002);

// PASO 4: Habilitar la monitorización en el Servicio 12 (PMODID 0)
// Esto activa el "vigilante" que chequea si el PID 15 se sale de los límites.
EmuGSS_TCProgram12_1 prog_FT_0110_step_4(FT_0110_TIME_step4,
        "FT_UAH_ASW_Event_Action_0110 step 4, Enable Monitoring PMODID 0",
        0);

EmuGSS_TCProgram20_3_uint8 prog_FT_0110_step_5(FT_0110_TIME_step5,
		"FT_UAH_ASW_Monitoring_0110 step 5, Update PID 15 to 99",15,99);


#endif



