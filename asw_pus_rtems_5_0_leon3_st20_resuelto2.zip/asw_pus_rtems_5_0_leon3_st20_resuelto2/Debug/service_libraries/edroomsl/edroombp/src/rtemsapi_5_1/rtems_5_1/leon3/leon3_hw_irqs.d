service_libraries/edroomsl/edroombp/src/rtemsapi_5_1/rtems_5_1/leon3/leon3_hw_irqs.o: \
 ../service_libraries/edroomsl/edroombp/src/rtemsapi_5_1/rtems_5_1/leon3/leon3_hw_irqs.c \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/edroomsl/edroombp/include/edroombp_swr/rtemsapi_5_1/rtems_5_1/leon3/leon3_hw_irqs.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/basic_types.h
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/edroomsl/edroombp/include/edroombp_swr/rtemsapi_5_1/rtems_5_1/leon3/leon3_hw_irqs.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/basic_types.h:
