service_libraries/pus_services/pus_tc_handler/src/pus_tc_handler.o: \
 ../service_libraries/pus_services/pus_tc_handler/src/pus_tc_handler.c \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/pus_services/pus_tc_handler/include/public/pus_tc_handler.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/basic_types.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/public/ccsds_pus.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/ccsds_pus/ccsds_pus_format.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/ccsds_pus/uah_pus_mission.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/config.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/asw/edroom_glue/include/edroom_glue/edroomdf.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/public/tmtc_dyn_mem.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tc_descriptor.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tm_descriptor.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tmtc_pool.h \
 /home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/serialize/include/public/serialize.h
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/pus_services/pus_tc_handler/include/public/pus_tc_handler.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/basic_types.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/public/ccsds_pus.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/ccsds_pus/ccsds_pus_format.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/ccsds_pus/include/ccsds_pus/uah_pus_mission.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/config/include/public/config.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/asw/edroom_glue/include/edroom_glue/edroomdf.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/public/tmtc_dyn_mem.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tc_descriptor.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tm_descriptor.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/llsw/tmtc_dyn_mem/include/tmtc_dyn_mem/tmtc_pool.h:
/home/atcsol/git/Pablo_Gonzalez_OBDH/asw_pus_rtems_5_0_leon3_st20_resuelto2/service_libraries/serialize/include/public/serialize.h:
